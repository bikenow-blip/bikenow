# BikeNow — tienda online de demostración

## Incluye
- Página responsive en español
- Catálogo de ejemplo, búsqueda y filtros
- Carrito funcional en el navegador
- Favoritos visuales y formulario de newsletter de demostración
- No requiere instalación ni herramientas de pago para probarla

## Probar en tu ordenador
1. Descomprime `bikenow_tienda.zip`.
2. Abre `index.html` en Chrome, Edge, Firefox o Safari.
3. Para cambiar productos, precios e imágenes, edita la lista `products` dentro del `<script>` de `index.html`.

## Publicar gratis con GitHub Pages
1. Crea una cuenta en https://github.com si no tienes una.
2. Crea un repositorio público llamado `bikenow`.
3. Sube `index.html` al directorio raíz del repositorio.
4. En el repositorio, entra en **Settings → Pages**.
5. En **Build and deployment**, elige **Deploy from a branch**, selecciona `main` y `/ (root)`, y pulsa **Save**.
6. Espera a que termine el despliegue. La dirección será parecida a `https://TU-USUARIO.github.io/bikenow/`.

## Importante antes de vender de verdad
Esta web es una demo front-end. El carrito no procesa pagos, no guarda pedidos y el formulario no recoge suscripciones. Para aceptar pedidos reales debes integrar una plataforma de pago/checkout o una solución de comercio electrónico, configurar envíos e impuestos, inventario, contacto y atención al cliente, y añadir los textos legales y la política de privacidad/cookies adecuados para tu negocio y jurisdicción. Los productos, precios, reseñas y mensajes comerciales son datos de ejemplo; revisa también las imágenes y sus licencias antes de uso comercial. Un dominio propio normalmente tiene coste; GitHub Pages permite publicar con una URL gratuita.
